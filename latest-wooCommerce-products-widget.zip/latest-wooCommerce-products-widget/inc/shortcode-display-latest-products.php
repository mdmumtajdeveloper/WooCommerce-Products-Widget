<?php
// Register the Shortcode
add_shortcode('latest_products', 'latest_products_shortcode');

function latest_products_shortcode($atts) {
    $atts = shortcode_atts(
        array(
            'limit' => 4, // Default limit is 4
        ),
        $atts,
        'latest_products'
    );

    ob_start();
    render_latest_products($atts['limit']);
    return ob_get_clean();
}

// Render latest products (function used in both widget and shortcode)
function render_latest_products($limit = 4) {
    // Query the latest products
    $args = array(
        'post_type'      => 'product',
        'posts_per_page' => $limit,
        'post_status'    => 'publish'
    );

    $query = new WP_Query($args);

    if ($query->have_posts()) {
        echo '<ul class="latest-products-list">';
        while ($query->have_posts()) {
            $query->the_post();
            global $product;
            // Get product details
            $product_id = get_the_ID();
            $product_url = get_permalink($product_id);
            $image_url = get_the_post_thumbnail_url($product_id, 'medium');
            $sku = $product->get_sku();
            $stock = $product->get_stock_quantity();
            $price = $product->get_regular_price();
            $sale_price = $product->get_sale_price();
            $is_in_stock = $product->is_in_stock();

            // Start the product block
            echo '<li class="product-item">';
            echo '<a href="' . esc_url($product_url) . '">';
            echo '<img src="' . esc_url($image_url) . '" alt="' . get_the_title() . '" />';
            echo '<h3>' . get_the_title() . '</h3>';
            echo '</a>';
            echo '<p>SKU: ' . esc_html($sku) . '</p>';

            if ($is_in_stock) {
                echo '<p>Stock: ' . esc_html($stock) . '</p>';
            } else {
                echo '<p>Out of stock</p>';
            }

            if ($sale_price) {
                echo '<p><del>' . wc_price($price) . '</del> ' . wc_price($sale_price) . '</p>';
            } else {
                echo '<p>' . wc_price($price) . '</p>';
            }

            echo '<a href="' . esc_url($product_url) . '" class="add-to-cart-btn">Add to Cart/More Options Available</a>';
            echo '</li>';
        }
        echo '</ul>';
    } else {
        echo '<p>No products found.</p>';
    }
    wp_reset_postdata();
}
