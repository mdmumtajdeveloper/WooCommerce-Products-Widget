document.addEventListener('DOMContentLoaded', function () {

    // Get all "Add to Cart" buttons
    const addToCartButtons = document.querySelectorAll('.add-to-cart-button');

    // Add click event listener to each button
    addToCartButtons.forEach(button => {
        button.addEventListener('click', function (e) {
            e.preventDefault(); // Prevent default link behavior

            const productId = this.getAttribute('href').split('=')[1]; // Get product ID from the link

            // Show a message or update something in the cart
            alert('Product ' + productId + ' added to the cart!');
            
            // This would be the place to handle Ajax cart requests if needed.
        });
    });
});
