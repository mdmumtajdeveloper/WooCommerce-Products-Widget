const gulp = require('gulp');
const sass = require('gulp-sass')(require('sass'));
const cleanCSS = require('gulp-clean-css');
const uglify = require('gulp-uglify');
const concat = require('gulp-concat');
const del = require('del');

// Clean CSS and JS directories
gulp.task('clean', function () {
    return del(['assets/css/*', 'assets/js/*']);
});

// Compile and minify SCSS to CSS
gulp.task('styles', function () {
    return gulp.src('assets/scss/*.scss')
        .pipe(sass().on('error', sass.logError))  // Compile SCSS
        .pipe(cleanCSS())  // Minify CSS
        .pipe(concat('styles.min.css'))  // Concatenate into one file
        .pipe(gulp.dest('assets/css/'));  // Output to assets/css
});

// Minify JS
gulp.task('scripts', function () {
    return gulp.src('assets/js/*.js')
        .pipe(uglify())  // Minify JS
        .pipe(concat('scripts.min.js'))  // Concatenate into one file
        .pipe(gulp.dest('assets/js/'));  // Output to assets/js
});

// Watch task (to automate re-building during development)
gulp.task('watch', function () {
    gulp.watch('assets/scss/**/*.scss', gulp.series('styles'));
    gulp.watch('assets/js/**/*.js', gulp.series('scripts'));
});

// Default task: Clean, build CSS/JS, and watch files
gulp.task('default', gulp.series('clean', 'styles', 'scripts', 'watch'));
