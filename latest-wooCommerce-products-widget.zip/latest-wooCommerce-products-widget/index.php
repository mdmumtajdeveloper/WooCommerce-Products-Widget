<?php
/*
Plugin Name: Latest WooCommerce Products Widget
Plugin URI:  https://test-assignment.com/
Description: Displays the latest WooCommerce products in a widget and shortcode.
Version: 1.0
Author:  Md Mumtaj
*/

// Check if WooCommerce is active
add_action( 'admin_notices', 'check_woocommerce_status' );
function check_woocommerce_status() {
    // Check if WooCommerce is active
    if ( ! is_plugin_active( 'woocommerce/woocommerce.php' ) ) {
        echo '<div class="error"><p><strong>My WooCommerce Products plugin:</strong> WooCommerce is not activated. Please activate WooCommerce to use this plugin.</p></div>';
         return;
    }
   
}

include( plugin_dir_path( __FILE__).'/inc/latest-products-widget.php');

//shortcode-display-latest products
include( plugin_dir_path( __FILE__).'/inc/shortcode-display-latest-products.php');


function enqueue_plugin_assets() {
    wp_enqueue_style('latest-products-css', plugin_dir_url(__FILE__) . 'assets/css/styles.min.css');
    wp_enqueue_script('latest-products-js', plugin_dir_url(__FILE__) . 'assets/js/scripts.min.js', array('jquery'), null, true);
}

add_action('wp_enqueue_scripts', 'enqueue_plugin_assets');

